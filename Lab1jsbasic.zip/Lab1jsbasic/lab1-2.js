console.log("(lab1-2) console.log() -- Hello World! 나는 허채림이다.");
document.write("<h1> (lab1-2) document.write() -- 하하하, 여기도 허채림!!! </h1>");
alert("(lab1-2) alert() -- 소프트웨어학부(20181707)");