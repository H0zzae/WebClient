// 배열을 생성합니다.
let array = [52, 273, '아침밥', '점심밥', true, false]
// 배열의 요소를 변경합니다.
array[0] = 0
// 요소를 출력합니다.
console.log(array[0]);
console.log(array[1]);
console.log(array[2]);
console.log(array[3]);
console.log(array[4]);
