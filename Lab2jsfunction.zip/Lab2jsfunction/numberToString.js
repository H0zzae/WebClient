console.log(52 + 273);
console.log("52" + 273);
console.log(52 + "273");
console.log("52" + "273");