﻿ // npm install request


let request=require('request');
let fs=require('fs');

console.log(__dirname);

let error = function (err) {
    if (err) {
        return console.log(err);
    }
    console.log("The file(google_page.html) was saved!");
}

let wF = function (err, res, body) {
    fs.writeFile(__dirname+"/temp/naver_page.html", body, error);
}
let homepage=request('http://www.naver.com', wF);

homepage.pipe(fs.createWriteStream(__dirname+"/temp/naver_page_pipe.html"));
let tO = function() {
    var timeout=5000;
    homepage.pipe(fs.createWriteStream(__dirname+"/temp/naver_page_pipe_delay5000.html"));
    console.log('The file(naver_page_pipe_delay5000.html) was saved after '+timeout+'msec');
}
setTimeout(tO, 5000);
