let output = "";
for (let i = 0; i < 10; i++) {
	for (let j = 0; j < 10 - i; j++) {
        output += ' ';
    }
    for (let j = 0; j < 2*i + 2; j+=1) {
        output += '*';
    }
    output += '\n';
}
console.log(output);
