const cheerio = require('cheerio');
const request = require('request');
const iconv = require('iconv-lite');
const express = require('express');
const app = express();

let url = "https://movie.naver.com/movie/running/current.nhn";

app.use((req, res) => {
    let output = ""

    output += "<style>";
    output += ".row { width: 990px; text-align: left; margin-top: -10px; margin-bottom: -10px; }";
    output += ".block {  width: 330px; vertical-align: middle; display: inline-block; line-height: 7px; } ";
    output += ".block h5 { margin-bottom: 1.71429rem; margin-top: 1.71429rem; }";
    output += "</style>";

    request({url, encoding: null}, function(error, response, body){
      let htmlDoc = iconv.decode(body,'UTF-8');
      const $ = cheerio.load(htmlDoc);
      let colArr = $("dl.lst_dsc");
      var names;
      for(let i = 0; i < 50; i++) {
          output += "<div class='row'>";
          output += "<div class='block'>";
          output += `<h2>${i+1}</h2>`;
          output += "</div>";
          output += "<div class='block'>";
          let src = $(`div.lst_wrap > ul > li:nth-child(${i+1}) > div > a > img`).attr('src');
          output += '<img src = '+src+'>'
          output += "</div>";
          output += "<div class='block'>";
          let title = $(`div.lst_wrap > ul > li:nth-child(${i+1}) > dl > dt > a`).text();
          output += "<h5>제목: "+title+"</h5>";
          let percent = $(`div.lst_wrap > ul > li:nth-child(${i+1}) > dl > dd.star > dl.info_exp > dd > div > span.num`).text();
          output += "<h5>예매율: "+percent+"%</h5>";
          let genre = '';
          $(`div.lst_wrap > ul > li:nth-child(${i+1}) > dl > dd:nth-child(3) > dl > dd:nth-child(2) > span.link_txt > a`).each(function(index, obj) {
              genre += $(this).text() +', '; });
          genre = genre.substring(0, genre.length-2);
          output += "<h5>장르: "+genre+"</h5>";
          let direct = '';
          $(`div.lst_wrap > ul > li:nth-child(${i+1}) > dl > dd:nth-child(3) > dl > dd:nth-child(4) > span > a`).each(function(index,obj){
              direct += $(this).text() +', '; });
          direct = direct.substring(0,direct.legnth);
          output += "<h5>감독: "+direct+"</h5>";
          let star ='';
          $(`div.lst_wrap > ul > li:nth-child(${i+1}) > dl > dd:nth-child(3) > dl > dd:nth-child(6) > span.link_txt > a`).each(function(index,obj){
              star += $(this).text() +', '; });
          star = star.substring(0,star.length-2);
          output += "<h5>출연: "+star+"</h5>";
          output += "</div>";
          output += "</div>";
          output += "<hr/>";
        }
        res.send(output);
    });

});


app.listen(52273, () => {
    console.log('Server running at http://127.0.0.1:52273');
});
