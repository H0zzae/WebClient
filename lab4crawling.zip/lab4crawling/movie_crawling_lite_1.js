﻿
const cheerio = require('cheerio');
const request = require('request');
const iconv = require('iconv-lite');


let url = "https://movie.naver.com/movie/running/current.nhn#";

request({url, encoding: null}, function(error, response, body){
    let htmlDoc = iconv.decode(body, 'CP949');
//    let htmlDoc = body;
    let resultArr = [];

    const $ = cheerio.load(htmlDoc);
    let colArr = $(".1st_detail_t1 li")
    for(let i = 0; i < colArr.length; i++)
        resultArr.push(colArr[i].1st_dsc.tit)

    console.log(resultArr)
});
