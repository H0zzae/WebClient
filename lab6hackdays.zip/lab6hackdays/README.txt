A Pen created at CodePen.io. You can find this one at https://codepen.io/chaobu/pen/qsyhf.

 Kevin, Tim and I came up with an idea to make more hackdays around Frankfurt/Germany. This is my first prototype of what it should be.