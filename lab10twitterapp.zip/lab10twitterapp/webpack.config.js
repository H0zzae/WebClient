module.exports = {
  target: "electron",
  node: {
    __dirname: false,
    __filename: false
  },
  resolve: {
    extensions: [".js", ".jsx"]
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        loader: "babel-loader"
      },
      {
        test: /\.css$/,
        loaders: ["style-loader", "css-loader?modules"]
      },
      {
        test: /\.vue$/,
        loader: 'vue-loader',
        options: {
          loaders: {
          }
          // other vue-loader options go here
        }
      }
    ]
  },
  entry: {
    "main/index": "./src/main/index.js",
    "renderer/app": "./src/renderer/app.js",
    "renderer/captureWindow": "./src/renderer/captureWindow.js",
    "renderer/pincodeWindow": "./src/renderer/pincodeWindow.js",
    "renderer/previewWindow": "./src/renderer/previewWindow.js",
    "main2/index": "./src2/main/index.js",
    "renderer2/app": "./src2/renderer/app.js",
    "renderer2/captureWindow": "./src2/renderer/captureWindow.js",
    "renderer2/pincodeWindow": "./src2/renderer/pincodeWindow.js",
    "renderer2/previewWindow": "./src2/renderer/previewWindow.js"
  },
  output: {
    filename: "dist/[name].js"
  },
  devtool: "source-map"
};
