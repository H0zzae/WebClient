import path from "path";
import fs from "fs";
import crypto from "crypto";

function getHash(buffer) {
  const shasum = crypto.createHash("sha1");
  shasum.update(buffer);
  return shasum.digest("hex");
}

class FileManager {
  constructor() {
    this.filePath = "";
  }

  saveFile(newFilePath, text, filePath) {
    return new Promise((resolve) => {
      //fs.writeFileSync(newFilePath, text);
      fs.renameSync(filePath, newFilePath);
      this.filePath = newFilePath;
      resolve();
    });
  }

  readFile(filePath) {
    return new Promise((resolve) => {
      const text = fs.readFileSync(filePath, "utf8");
      this.filePath = filePath;
      resolve(text);
    });
  }

  overwriteFile(text) {
    return new Promise((resolve) => {
      this.saveFile(this.filePath, text).then(resolve());
    });
  }

  // TODO: 동기 처리로 구현하는 것이 이해하기 쉽다기에 변경
  writeImage(dir, image) {
    return new Promise((resolve, reject) => {
      const buffer = image.toPNG();
      const filename = path.join(dir, `${getHash(buffer)}.png`);
      console.log('createdFilename:' + filename);
      fs.writeFile(filename, buffer, error => {
        if (error) {
          reject(error);
        } else {
          resolve(filename);
        }
      });
    });
  }

  readAsBase64string(filename, filename2) {
    return new Promise((resolve, reject) => {
      fs.readFile(filename, { encoding: "base64" }, (error, data) => {
        if (error) {
          reject(error);
        } else {
          //resolve(data);
          fs.readFile(filename2, { encoding: "base64" }, (error, data2) => {
            if (error) {
              reject(error);
            } else {
              resolve([data, data2]);
            }
          });
        }
      });
    });
  }
}

function createFileManager() {
  return new FileManager();
}

export default createFileManager;
