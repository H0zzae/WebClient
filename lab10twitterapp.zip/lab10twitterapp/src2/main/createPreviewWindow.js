import { BrowserWindow, ipcMain } from "electron";
import { EventEmitter } from "events";
import createFileManager from "./createFileManager";
import createTwitterLoginManager from "./createTwitterLoginManager";

// 트위터 화면을 열어주는 역할
class PreviewWindow extends EventEmitter {
  constructor({ filename }) {
    super();
    this.win = new BrowserWindow({
      width: 500,
      height: 430
    });
    this.fileManager = createFileManager();
    this.filename = filename;
    this.filename2 = filename;
    console.log('filename:' + filename);
    this.win.loadURL(`file://${__dirname}/../../static2/previewWindow.html?filename=${filename}`);
    const handler = this.handlePostTweet.bind(this);
    ipcMain.on("POST_TWEET", handler);
    this.win.on("close", () => {
      ipcMain.removeListener("POST_TWEET", handler);
    });
  }

  requestText() {
    return new Promise((resolve) => {
      this.win.webContents.send("REQUEST_TEXT");
      ipcMain.once("REPLY_TEXT", (_e, text) => resolve(text));
    });
  }

  sendText(text) {
    this.win.webContents.send("SEND_TEXT", text);
  }

handlePostTweet(e, args) {
  console.log('[handlePostTweet]');
    this.postTweet(args).then(url => {
      e.sender.send("REPLY_POST_TWEET", { url });
      this.emit("DONE_TWEET", { url });
    }).catch(error => {
      e.sender.send("REPLY_POST_TWEET", { error });
    });
  }

  postTweet({ message }) {
    console.log('[postTweet]');
    const loginManager = createTwitterLoginManager(); // 트위터 로그인
    return loginManager.init().then(() => {
      const client = loginManager.createClient(); // 가입자의 ID/PW를 가지고 있는 객체
      console.log('file1', this.filename);
      console.log('file2', this.filename2);
      return this.fileManager.readAsBase64string(this.filename, this.filename2) // 인터넷으로 파일을 보낼 때 사용
        .then(data => client.uploadMedia([{ media: data[0] }, { media: data[1] }])) // data는 위의 명령어의 return값
        .then(media => {
          return client.updateStatuses({
            status: message,
            media_ids: media[0].media_id_string + "," + media[1].media_id_string // 배열로 하기
          });
        })
        .then(status => {
          return `https://twitter.com/${status.user.name}/statuses/${status.id_str}`;
        })
      ;
    });
  }

  close() {
    this.win.close();
  }
}

function createPreviewWindow({ filename }) {
  return new PreviewWindow({ filename });
}

export default createPreviewWindow;
