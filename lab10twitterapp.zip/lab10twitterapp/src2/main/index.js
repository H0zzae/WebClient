import { app, shell, ipcMain } from "electron";
import createFileManager from "./createFileManager";
import trimDesktop from "./trimDesktop";
import createCaptureWindow from "./createCaptureWindow";
import createPreviewWindow from "./createPreviewWindow";
import setAppMenu from "./setAppMenu";
import showSaveAsNewFileDialog from "./showSaveAsNewFileDialog";
import showOpenFileDialog from "./showOpenFileDialog";

let captureWindow;
let fileManager = null;
let previewWindow = null;
let currentImage;

function openFile1() {
  showOpenFileDialog()
//    .then((filePath) => fileManager.readFile(filePath))
//    .then((text) => previewWindow.sendText(text))
//    비동기 통신방식 Promise 객체, 파일 선택이 완료되면 then으로 들어가고, 취소 버튼을 클릭하면 catch로 들어간다.
    .then((filePath) => { // 파일이 선택됐을 때, 결과값이 filePath에 저장되어 콜백함수의 입력으로 사용된다.
       let x = currentImage;
       currentImage = filePath;
       console.log('filePath: ' + filePath);
       previewWindow.filename = filePath; // 하드 디스크에서는 이 이미지를 previewWindow 객체의 filename에 저장한다.
       previewWindow.win.webContents.send("NEW_IMAGE1", filePath );
       return x;
    })
    .catch((error) => {
      console.log(error);
    });
}

function openFile2() {
  showOpenFileDialog()
//    .then((filePath) => fileManager.readFile(filePath))
//    .then((text) => previewWindow.sendText(text))
    .then((filePath) => {
       let x = currentImage;
       currentImage = filePath;
       console.log('filePath: ' + filePath);
       previewWindow.filename2 = filePath;
       previewWindow.win.webContents.send("NEW_IMAGE2", filePath );
       return x;
    })
    .catch((error) => {
      console.log(error);
    });
}

function saveFile() {
  if (!fileManager.filePath) {
    saveAsNewFile();
  }
  previewWindow.requestText()
    .then((text) => fileManager.overwriteFile(text))
    .catch((error) => {
      console.log(error);
    });
}

function saveAsNewFile() {
  return Promise.all([ showSaveAsNewFileDialog(), previewWindow.requestText() ])
    .then(([filePath, text]) => {
       let x = currentImage;
       currentImage = filePath;
       x = fileManager.saveFile(filePath, text, x);
       console.log('filePath: ' + filePath);
       previewWindow.filename = filePath;
       previewWindow.win.webContents.send("NEW_IMAGE1", filePath );
       return x;
     })
    .catch((error) => {
      console.log(error);
    });
}

function captureAndOpenItem() {
  fileManager = createFileManager();
  return trimDesktop()
    .then(captureWindow.capture.bind(captureWindow))
    .then(image => {
      // 임시 파일 저장 전용 폴더에 추출한 이미지 저장하기
      //const createdFilename = fileManager.writeImage(app.getPath("temp"), image);
      const createdFilename = fileManager.writeImage(__dirname + '/../../capture', image);
      return createdFilename;
    })
    .then(shell.openItem.bind(shell))
    .then(() => {
      if (process.platform !== "darwin") {
        app.quit();
      }
    })
  ;
}

function captureProcess() {
  return new Promise(resolve => {
    trimDesktop()
    .then(captureWindow.capture.bind(captureWindow))
    .then(image => {
      // 임시 파일 저장 전용 폴더에 추출한 이미지 저장하기
      console.log(__dirname + '/../../capture');
      //const createdFilename = fileManager.writeImage(app.getPath("temp"), image);
      const createdFilename = fileManager.writeImage(__dirname + '/../../capture', image);
      console.log('createdFilename:' + createdFilename);
      resolve(createdFilename);
    })
  })
}

function controlPanel(filename) {
  return new Promise(resolve => {
      currentImage = filename;
      console.log('[controlPanel]');
      console.log('filename, currentImage:' + filename + ', ' + currentImage);
      previewWindow = createPreviewWindow({ filename, filename });
      // 트윗 완료 때의 처리
      previewWindow.once("DONE_TWEET", ({ url }) => {
        shell.openExternal(url);
        //previewWindow.close();
        //if (process.platform !== "darwin") {
        //  previewWindow.quit();
        //}
        //resolve(888);
      });

      ipcMain.once("EXIT_APP", () => {
        console.log('EXIT_APP arrived...');
        app.quit();
      });

      ipcMain.once("START_CAPTURE", () => {
        console.log('START_CAPTURE arrived...');
        previewWindow.close();
        //if (process.platform !== "darwin") {
        //  previewWindow.quit();
        //}
        previewWindow.__proto__ = null;
        previewWindow = null;
//        delete previewWindow;
        resolve(888);
      });
  })
}

async function captureAndPost() {
  fileManager = createFileManager();
  currentImage = __dirname + '/../../capture/balloon.png';
  console.log('currentImage: ' + currentImage);

  while(true) {
    let x = await controlPanel(currentImage);
    console.log('controlPanel: ' + x);
    x = await captureProcess();
    console.log('captureProcess(): ' + x);
    currentImage = x;
  }

 return 777;
}

app.on("ready", () => {
  captureWindow = createCaptureWindow();
  const options = { openFile1, saveFile, saveAsNewFile, openFile2 };
  setAppMenu(options);
// captureAndOpenItem();
  let state = captureAndPost();
  console.log('state: ' + state);
});
