import { dialog } from "electron";

function showSaveAsNewFileDialog() {
  return new Promise((resolve, reject) => {
    const file = dialog.showSaveDialog(
      {
        title: "save",
        filters: [ { name: "twitter image file", extensions: [ "png" ] } ]
      }
    );
    if (file) {
      resolve(file);
    } else {
      reject();
    }
  });
}

export default showSaveAsNewFileDialog;
