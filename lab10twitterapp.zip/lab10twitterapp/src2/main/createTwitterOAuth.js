import { OAuth } from "oauth";

function createTwitterOAuth() {
  return new OAuth(
    "https://api.twitter.com/oauth/request_token",
    "https://api.twitter.com/oauth/access_token",
    "XJdWzDxUrXAVsJzhcxobPNTLI",
    "67j5pDeXsuTFHM9m4Y0zDavP4jU4FiR9sW8u36ZZHhhIgPc5k8",
    "1.0A",
    null,
    "HMAC-SHA1"
  );
}

export default createTwitterOAuth;
