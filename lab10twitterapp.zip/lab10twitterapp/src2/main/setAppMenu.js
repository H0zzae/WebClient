import { app, Menu, BrowserWindow } from "electron";

function setAppMenu(options) {
  const template = [
    {
      label: "File",
      submenu: [
        { label: "Open1", accelerator: "CmdOrCtrl+O+1", click: () => options.openFile1() },
        { label: "Open2", accelerator: "CmdOrCtrl+O+2", click: () => options.openFile2() },
        { label: "Save", accelerator: "CmdOrCtrl+S", click: () => options.saveFile() },
        { label: "Save As...", click: () => options.saveAsNewFile() }
      ]
    },
    {
      label: "Edit",
      submenu: [
        { label: "Copy", accelerator: "CmdOrCtrl+C", role: "copy" },
        { label: "Paste", accelerator: "CmdOrCtrl+V", role: "paste" },
        { label: "Cut", accelerator: "CmdOrCtrl+X", role: "cut" },
        { label: "Select All", accelerator: "CmdOrCtrl+A", role: "selectall" }
      ]
    },
    {
      label: "View",
      submenu: [
        {
          label: "Toggle DevTools",
          accelerator: "Alt+Command+I",
          click: () => BrowserWindow.getFocusedWindow().toggleDevTools()
        }
      ]
    }
  ];
  if (process.platform === "darwin" ) {
    template.unshift(
      {
        label: "Desktop Capturer",
        submenu: [
          { label: "Quit", accelerator: "CmdOrCtrl+Q", click: () => app.quit() }
        ]
      }
    );
  }
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}
export default setAppMenu;
