<template>
  <div class="root" ref="root">
    <div class="image">
      <div>
        <img v-bind:src="image1" />
      </div>
      <div>
        <img v-bind:src="image2" />
      </div>
    </div>
    <form class="form" v-on:submit="handleOnSubmit">
      <input
        class="form-control"
        placeholder="tweet message"
        v-model="message"
        v-on:change="handleOnChangeMessage"
      />
      <div v-if="sending" class="sending">
        <div class="icon icon-hourglass" />
      </div>
      <button v-if="!sending" type="submit" class="btn btn-default">
        <span class="icon icon-twitter" /> Tweet
      </button>
      <button class="btn btn-default" v-on:click="handleOnCapture">
        <span class="icon icon-twitter" /> Capture
      </button>
      <button class="btn btn-default" v-on:click="handleOnExit">
        <span class="icon icon-twitter" /> Exit
      </button>
    </form>
  </div>
</template>

<script>
import { ipcRenderer } from "electron";

export default {

  props: ['src'],

  data() {
    return {
      image1: "",
      image2: "",
      message: "",
      sending: false
    }
  },

  created: function() {
    this.image1 = this.src;
    this.image2 = this.src;
    console.log('[created : function(Figure1)] src, this.image = ' + this.src + ', ' + this.image1);
    console.log('[created : function(Figure2)] src, this.image = ' + this.src + ', ' + this.image2);
    this.handleOnChangeMessage = this.handleOnChangeMessage.bind(this);
    this.handleOnSubmit = this.handleOnSubmit.bind(this);
    this.handleOnCapture = this.handleOnCapture.bind(this);
    this.handleOnExit = this.handleOnExit.bind(this);
  },


    mounted: function() {
      console.log('mounted');

      ipcRenderer.on("REQUEST_TEXT", () => {
        ipcRenderer.send("REPLY_TEXT", this.message);
      });

      ipcRenderer.on("SEND_TEXT", (_e, text) => {
        this.message = text;
      });

      ipcRenderer.on("NEW_IMAGE1", (_e, filePath) => {
        console.log('filePath: ' + filePath)
        console.log('image1: ' + this.image1)
        this.image1 = filePath;
      });

      ipcRenderer.on("NEW_IMAGE2", (_e, filePath) => {
        console.log('filePath: ' + filePath)
        console.log('image1: ' + this.image2)
        this.image2 = filePath;
      });

      ipcRenderer.on("REPLY_POST_TWEET", (e, args) => {
        if (args.error) {
          this.sending = false;
        } else {
          this.message = "";
          this.sending = false;
        }
      });
    },

    beforeDestroy: function() {
      ipcRenderer.removeAllListeners("REPLY_POST_TWEET");
    },

    methods: {
      handleOnChangeMessage(e) {
        console.log('handleOnChangeMessage');
        this.message = e.target.value;
      },

      // tweet 버튼이 클릭됐을 때 동작하는 부분
      handleOnSubmit(e) {
        const message = this.message;
        const sending = this.sending;
        console.log('[handleOnSubmit]');
        console.log('message: ', message);
        console.log('sending: ', sending);
        if (!message.length || sending) { // 메시지가 없거나, 보내는 중이면 종료
          return;
        }
        console.log('[POST_TWEET] start');
        console.log('call main/createPreviewWindow');
        ipcRenderer.send("POST_TWEET", { message });
        console.log('[POST_TWEET] end');
        this.sending = true;
        e.preventDefault();
      },

      handleOnCapture(e) {
        console.log('START_CAPTURE sending...');
        ipcRenderer.send("START_CAPTURE");
        e.preventDefault();
      },

      handleOnExit(e) {
        console.log('EXIT_APP sending...');
        ipcRenderer.send("EXIT_APP");
        e.preventDefault();
      }
    }
}
</script>

<style src="./Viewer.css" />


/*
import React from "react";
import { ipcRenderer } from "electron";
import styles from "./Viewer.css";

export default class Viewer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      src: "",
      message: "",
      sending: false
    };
    this.state.src = props.src;
    console.log('this.props.src, this.state.src = ' + this.props.src + ', ' + this.state.src);
    this.handleOnChangeMessage = this.handleOnChangeMessage.bind(this);
    this.handleOnSubmit = this.handleOnSubmit.bind(this);
    this.handleOnCapture = this.handleOnCapture.bind(this);
    this.handleOnExit = this.handleOnExit.bind(this);
  }

  componentDidMount() {
    ipcRenderer.on("REQUEST_TEXT", () => {
      ipcRenderer.send("REPLY_TEXT", this.state.message);
    });
    ipcRenderer.on("SEND_TEXT", (_e, text) => {
      this.setState({ message: text });
    });

    ipcRenderer.on("NEW_IMAGE", (_e, filePath) => {
      console.log('filePath: ' + filePath)
      console.log('src: ' + this.state.src)
      this.setState({ src: filePath });
    });

    ipcRenderer.on("REPLY_POST_TWEET", (e, args) => {
      if (args.error) {
        this.setState({ sending: false });
      } else {
        this.setState({
          message: "",
          sending: false
        });
      }
    });
  }

  componentWillUnmount() {
    ipcRenderer.removeAllListeners("REPLY_POST_TWEET");
  }

  handleOnChangeMessage(e) {
    this.setState({ message: e.target.value });
  }

  handleOnSubmit(e) {
    const { message, sending } = this.state;
    if (!message.length || sending) {
      return;
    }
    ipcRenderer.send("POST_TWEET", { message });
    this.setState({ sending: true });
    e.preventDefault();
  }

  handleOnCapture(e) {
    console.log('START_CAPTURE sending...');
    ipcRenderer.send("START_CAPTURE");
    e.preventDefault();
  }

  handleOnExit(e) {
    console.log('EXIT_APP sending...');
    ipcRenderer.send("EXIT_APP");
    e.preventDefault();
  }

  renderTweetBtn() {
    if (this.state.sending) {
      return (
        <div className={styles.sending}>
          <div className="icon icon-hourglass" />
        </div>
      );
    } else {
      return (
        <button type="submit" className="btn btn-default">
          <span className="icon icon-twitter" /> Tweet2
        </button>
      );
    }
  }

  render() {
    return (
      <div className={styles.root} ref="root">
        <div className={styles.image}>
          <div>
            <img src={this.state.src} />
          </div>
        </div>
        <form className={styles.form} onSubmit={this.handleOnSubmit}>
          <input
            className="form-control"
            placeholder="tweet message"
            value={this.state.message}
            onChange={this.handleOnChangeMessage}
          />
          {this.renderTweetBtn()}
          <button className="btn btn-default" onClick={this.handleOnCapture}>
            <span className="icon icon-twitter" /> Capture
          </button>
          <button className="btn btn-default" onClick={this.handleOnExit}>
            <span className="icon icon-twitter" /> Exit
          </button>
        </form>
      </div>
    );
  }
}
*/
