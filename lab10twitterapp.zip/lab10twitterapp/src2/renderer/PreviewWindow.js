//import React from "react";
//import { render } from "react-dom";
import Vue from 'vue';
import Viewer from "./Viewer.vue";

const filename = new URL(location.href).searchParams.get("filename");

// render(<Viewer src={`file://${filename}`} />, document.getElementById("app"));
new Vue({
  el: '#app',
  render: h => h(Viewer, { props: { src: `file://${filename}` } })
})
