import createTwitterOAuth from "../../src/main/createTwitterOAuth";
import createTwitterClient from "../../src/main/createTwitterClient";

const client = createTwitterClient(
  createTwitterOAuth(),
  "1135198895586258944-AAjKOdx0ZBJ5W31I1e3Udp72HPjC5P",
  "9ncm8l9Vk9zU4L82bLcnvOalFwj0tMvRKNszm13lfv4Yw"
);

client.verifyCredentials().then(data => {
  console.log(data);
}).catch(error => {
  console.log(error);
});
