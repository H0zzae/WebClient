<template>
  <div class="root" v-on:mousedown="handleOnMouseDown" v-on:mouseup="handleOnMouseUp"  v-on:mousemove="handelOnMouseMove"  v-on:mouseenter="handleOnMouseEnter"  >
    <div v-if="isClipping" class="rect"  v-bind:style="drawRect" />
    <div v-if="!isClipping" />
  </div>
</template>

<script>
import { ipcRenderer } from "electron";

function position2Bounds({ x1, x2, y1, y2 }){
  const x = Math.min(x1, x2);
  const y = Math.min(y1, y2);
  const width =  Math.abs(x2 - x1);
  const height = Math.abs(y2 - y1);
  return { x, y, width, height };
}

export default {

  props: [],

  data() {
    return {
      isClipping: false,
      clientPosition: {},
      screenPosition: {},
      drawRect: {}
    }
  },

  created: function() {
    this.handleOnMouseDown = this.handleOnMouseDown.bind(this);
    this.handleOnMouseUp = this.handleOnMouseUp.bind(this);
    this.handelOnMouseMove = this.handelOnMouseMove.bind(this);
    this.handleOnMouseEnter = this.handleOnMouseEnter.bind(this);
  },

  methods: {

    // 드래그 시작 때의 처리
    handleOnMouseDown(e) {
    console.log('handleOnMouseDown');
      const clientPosition2 = {
        x1: e.clientX, y1: e.clientY,
        x2: e.clientX, y2: e.clientY
      };
      const screenPosition2 = {
        x1: e.screenX, y1: e.screenY,
        x2: e.screenX, y2: e.screenY
      }
      this.isClipping = true;
      this.clientPosition = clientPosition2;
      this.screenPosition = screenPosition2;
    },

    // 드래그 종료 때의 처리
    handleOnMouseUp() {
    console.log('handleOnMouseUp');
      this.isClipping = false;
      // 사각형 정보를 위치 정보로 변환하기
      const trimmedBounds = position2Bounds(this.screenPosition);
      if (trimmedBounds.width > 100 && trimmedBounds.height > 100) {
        // 자를 대상 위치 정보를 Main 프로세스에 전송하기
        ipcRenderer.send("SEND_BOUNDS", { trimmedBounds });
      }
    },

    // 드래그 중의 처리
    handelOnMouseMove(e) {
    console.log('handleOnMouseMove');
      if (!this.isClipping) return;
      const clientPosition2 = this.clientPosition;
      clientPosition2.x2 = e.clientX;
      clientPosition2.y2 = e.clientY;
      const screenPosition2 = this.screenPosition;
      screenPosition2.x2 = e.screenX;
      screenPosition2.y2 = e.screenY;
      this.clientPosition = clientPosition2;
      this.screenPosition = screenPosition2;
    },

    // 사각형 영역에 테두리를 그리는 처리
    handleOnMouseEnter(e) {
      if (!e.buttons) {
        this.isClipping = false;
      }
    }

  },

  computed: {
    renderRect: function() {
      const bounds = position2Bounds(this.clientPosition);
      const inlineStyle = {
        left:   bounds.x,
        top:    bounds.y,
        width:  bounds.width,
        height: bounds.height
      };
      //return inlineStyle;
      this.drawRect = inlineStyle;
    }
  }
 }
</script>

/*
  render() {
    return (
      <div className={styles.root}
        onMouseDown={this.handleOnMouseDown}
        onMouseUp={this.handleOnMouseUp}
        onMouseMove={this.handelOnMouseMove}
        onMouseEnter={this.handleOnMouseEnter}
      >
        { this.state.isClipping ? this.renderRect() : <div />}
      </div>
    );
  }
}
*/

<style src="./Trimmer.css" />
