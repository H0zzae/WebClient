//import React from "react";
//import { render } from "react-dom";
import Vue from 'vue';
import "./app.css";
import Trimmer from "./Trimmer.vue";

//render(<Trimmer />, document.getElementById("app"));
new Vue({
  el: '#app',
  render: h => h(Trimmer)
})
