//import React from "react";
//import { render } from "react-dom";
import Vue from 'vue';
import Viewer from "./Viewer.vue";

const filename = new URL(location.href).searchParams.get("filename");

new Vue({
  el: '#app',
  render: h => h(Viewer, { props: { src: `file://${filename}` } })
})
