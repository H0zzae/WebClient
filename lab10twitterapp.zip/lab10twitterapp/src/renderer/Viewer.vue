<template>
  <div class="root" ref="root">
    <div class="image">
      <div>
        <img v-bind:src="src" />
      </div>
    </div>
    <form class="form" v-on:submit="handleOnSubmit">
      <input
        class="form-control"
        placeholder="tweet message"
        v-model="message"
        v-on:change="handleOnChangeMessage"
      />
      <div v-if="sending" class="sending">
        <div class="icon icon-hourglass" />
      </div>
      <button v-if="!sending" type="submit" class="btn btn-default">
        <span class="icon icon-twitter" /> Tweet
      </button>
    </form>
  </div>
</template>

<script>
import { ipcRenderer } from "electron";

export default {

  props: ['src'],

  data() {
    return {
      message: "",
      sending: false
    }
  },

  created: function() {
    this.handleOnChangeMessage = this.handleOnChangeMessage.bind(this);
    this.handleOnSubmit = this.handleOnSubmit.bind(this);
  },

  mounted: function() {
    console.log('mounted');
    ipcRenderer.on("REPLY_POST_TWEET", (e, args) => {
      if (args.error) {
        this.sending = false;
      } else {
        this.message = "";
        this.sending = false;
      }
    });
  },

  beforeDestroy: function() {
    ipcRenderer.removeAllListeners("REPLY_POST_TWEET");
  },

  methods: {

    handleOnChangeMessage(e) {
      console.log('handleOnChangeMessage');
      this.message = e.target.value;
    },

    handleOnSubmit(e) {
      const message = this.message;
      const sending = this.sending;
      if (!message.length || sending) {
        return;
      }
      ipcRenderer.send("POST_TWEET", { message });
      this.sending = true;
      e.preventDefault();
    }
  }
}
</script>

/*
renderTweetBtn() {
  if (this.state.sending) {
    return (
      <div className={styles.sending}>
        <div className="icon icon-hourglass" />
      </div>
    );
  } else {
    return (
      <button type="submit" className="btn btn-default">
        <span className="icon icon-twitter" /> Tweet
      </button>
    );
  }
}

  render() {
    return (
      <div className={styles.root} ref="root">
        <div className={styles.image}>
          <div>
            <img src={this.props.src} />
          </div>
        </div>
        <form className={styles.form} onSubmit={this.handleOnSubmit}>
          <input
            className="form-control"
            placeholder="tweet message"
            value={this.state.message}
            onChange={this.handleOnChangeMessage}
          />
          {this.renderTweetBtn()}
        </form>
      </div>
    );
  }
*/

<style src="./Viewer.css" />
