<template>
  <form class="root" v-on:submit="handleOnSubmit">
    <input
      class="form-control"
      placeholder="Input PIN code"
      v-model="pincode"
      v-on:change="handleOnChange"
    />
    <div class="buttons">
      <button type="button" class="btn btn-default" v-on:click="handleOnClickCancel">Cancel</button>
      <button type="submit" class="btn btn-primary">OK</button>
    </div>
  </form>

</template>

<script>
import { ipcRenderer } from "electron";

export default {

  props: [],

  data() {
    return {
      pincode: ""
    }
  },

  created: function() {
    this.handleOnChange = this.handleOnChange.bind(this);
    this.handleOnSubmit = this.handleOnSubmit.bind(this);
    this.handleOnClickCancel = this.handleOnClickCancel.bind(this);
  },

  methods: {
    handleOnChange(e) {
      this.pincode = e.target.value;
    },

    handleOnSubmit() {
    let pincode = this.pincode;
      if (!pincode) {
        return;
      }
      ipcRenderer.send("SEND_PIN", { pincode });
    },

    handleOnClickCancel() {
      ipcRenderer.send("CANCEL_PIN");
    },
  }
}
</script>

<style src="./Pincode.css" />
