//import React from "react";
//import { render } from "react-dom";
import Vue from 'vue';
import Pincode from "./Pincode.vue";

//render(<Pincode />, document.getElementById("app"));
new Vue({
  el: '#app',
  render: h => h(Pincode)
})
