import { OAuth } from "oauth";

function createTwitterOAuth() {
  return new OAuth(
    "https://api.twitter.com/oauth/request_token",
    "https://api.twitter.com/oauth/access_token",
    "qWYjD8Wl5WIjNbtPhRrVB7oKe",
    "3T8SvtBDEmf5OOLhIScqJm4lBtMZl8qIfshJCzcCJ7Jz3AxxLH",
    "1.0A",
    null,
    "HMAC-SHA1"
  );
}

export default createTwitterOAuth;
