<template>
    <div class="card">
      <div class="card-content">
        No messages.
      </div>
    </div>
</template>
