module.exports = {
  production: 'production',
  development: 'development',
  testing: 'testing',
};
