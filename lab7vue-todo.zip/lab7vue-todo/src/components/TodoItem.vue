<template>
  <div class="content" v-show="!isEditing">
    <i class="checkBtn fas fa-check" aria-hidden="true"></i>
    {{ todoItem }}
    <span class="removeBtn" type="button" @click="removeTodo(todoItem, index)">
      <i class="far fa-trash-alt" aria-hidden="true"></i>
    </span>
    <span class="editBtn" type="button" @click="showForm">
      <i class="far fa-edit" aria-hidden="true"></i>
    </span>
  </div>
  <div class="content" v-show="isEditing">
    <i class="checkBtn fas fa-check" aria-hidden="true"></i>
    <input type="text" v-model="propsdata[index]" >
      <button class="ui basic blue button" @click="hideForm">
        Close X
      </button>
  </div>  
</template>
