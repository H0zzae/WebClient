<template>
      <li class="shadow">
        <div class="content" v-show="!isEditing">
          <i class="checkBtn fas fa-check" aria-hidden="true"></i>
          {{ inputValue }}
          <span class="removeBtn" type="button" @click="removeTodo(items,idx)">
            <i class="far fa-trash-alt" aria-hidden="true"></i>
          </span>
          <span class="editBtn" type="button" @click="showForm">
            <i class="far fa-edit" aria-hidden="true"></i>
          </span>
        </div>
        <div class="content" v-show="isEditing">
          <i class="checkBtn fas fa-check" aria-hidden="true"></i>
          <input type="text" v-model="inputValue" >
            <button class="ui basic blue button" @click="hideForm">
              Close X
            </button>
        </div>
      </li>
</template>

<script>
export default {
  props: ['todoItems', 'todoItem','index'],
  data(){
    return{
      isEditing:false,
      inputValue:'',
      idx:0,
      items:this.todoItems,
    }
  },
  created(){
    this.inputValue = this.todoItem;
    this.idx = this.index;
  },
  methods: {
    removeTodo(items,index) {
      index = items.length-1;
      while(items[index] !=this.todoItem){
        index-=1;
      }
      this.$emit('removeTodo', this.todoItem, index);
    },
    showForm() {
      this.isEditing = true;
    },
    hideForm() {
      this.isEditing = false;
    }
  }
}
</script>

<style scoped>
  ul {
    list-style-type: none;
    padding-left: 0px;
    margin-top: 0;
    text-align: left;
  }
  li {
    display: flex;
    min-height: 50px;
    height: 50px;
    line-height: 50px;
    margin: 0.5rem 0;
    padding: 0 0.9rem;
    background: white;
    border-radius: 5px;
  }
  .checkBtn {
    line-height: 45px;
    color: #62acde;
    margin-right: 5px;
  }
  .removeBtn {
    margin-left: auto;
    color: #de4343;
  }

  .list-enter-active, .list-leave-active {
    transition: all 1s;
  }
  .list-enter, .list-leave-to {
    opacity: 0;
    transform: translateY(30px);
  }
</style>
