﻿// npm install request


let request=require('request');
let fs=require('fs');

console.log(__dirname);

let homepage=request('http://api.openweathermap.org/data/2.5/forecast?q=Busan&units=metric&lang=kr&appid=a1a951a4e63b35130ec5d3e15799cfb7', function(err, res, body){
    fs.writeFile(__dirname+"/test/request_Busan.json", body, function(err) {
        if(err) {
            return console.log(err);
        }
        let tableData = JSON.parse(body)
        for(let i=0;i<37;i++){
        console.log();
        console.log("도시 :",tableData.city.name)
        console.log("국가 :",tableData.city.country)
        console.log("시간 :",tableData.list[i].dt_txt)
        console.log("날씨 :",tableData.list[i].weather[0].description)
        console.log("평균온도 :",tableData.list[i].main.temp,"(℃)")
        console.log("최고온도 :",tableData.list[i].main.temp_max,"(℃)")
        console.log("최저온도 :",tableData.list[i].main.temp_min,"(℃)")
        console.log("풍속 :",tableData.list[i].wind.speed,"m/s")
        console.log("습도 :",tableData.list[i].main.humidity,"%")
        console.log();
        console.log("=================================");
      };
    });
});
//
// homepage.pipe(fs.createWriteStream(__dirname+"/test/request_Busan.json"));

// setTimeout(function(){
//     var timeout=5000;
//     homepage.pipe(fs.createWriteStream(__dirname+"/temp/naver_page_pipe_delay5000.html"));
//     console.log('The file(naver_page_pipe_delay5000.html) was saved after '+timeout+'msec');
//     }, 5000);
