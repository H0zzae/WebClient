// 기본 자료형
let number = 273;
let string = '안녕하세요';
let boolean = true;
// 자료형을 출력합니다.
console.log(typeof number);
console.log(typeof string);
console.log(typeof boolean);
