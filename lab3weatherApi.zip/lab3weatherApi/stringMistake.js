// 변수를 선언합니다.
let string = 'abcdefg';
// 출력합니다.
string.toUpperCase();
console.log(string);