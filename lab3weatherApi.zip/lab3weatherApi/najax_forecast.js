﻿// npm install najax


let najax = $ = require('najax');
let fs=require('fs');


function getData(callback) {
	var tableData;
	$.get('http://api.openweathermap.org/data/2.5/weather?q=Seoul&units=metric&lang=kr&appid=a1a951a4e63b35130ec5d3e15799cfb7', callback)
	return tableData;
}

getData(function (response) {
       fs.writeFile(__dirname+"/test/najax_forecast_seoul.json", response, function(err) {
           if(err) {
               return console.log(err);
           }
		   tableData = JSON.parse(response);
									 console.log("도시 :",tableData.name)
									 console.log("국가 :",tableData.sys.country)
									 console.log("날씨 :",tableData.weather[0].description)
									 console.log("평균온도 :",tableData.main.temp,"(℃)");
									 console.log("최고온도 :",tableData.main.temp_max,"(℃)")
									 console.log("최저온도 :",tableData.main.temp_min,"(℃)")
									 console.log("풍속 :",tableData.wind.speed,"m/s")
									 console.log("습도 :",tableData.main.humidity,"%")

         });
});
